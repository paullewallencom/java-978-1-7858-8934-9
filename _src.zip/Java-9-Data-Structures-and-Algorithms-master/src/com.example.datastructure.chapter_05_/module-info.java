module com.example.datastructure.chapter_05_{
	exports com.example.search;
}
