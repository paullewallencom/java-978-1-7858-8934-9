package com.example.reactive;

/**
 * Created by debasishc on 29/1/17.
 */
public interface Task {
}
