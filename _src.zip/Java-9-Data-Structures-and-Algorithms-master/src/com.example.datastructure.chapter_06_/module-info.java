module com.example.datastructure.chapter_06_{
	exports com.example.sort;
	requires com.example.datastructure.chapter_04_;
}
