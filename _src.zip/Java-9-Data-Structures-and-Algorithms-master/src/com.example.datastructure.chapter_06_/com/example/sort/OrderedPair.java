package com.example.sort;

/**
 * Created by debasishc on 4/10/16.
 */
public class OrderedPair<E,F> {
    public E _1;
    public F _2;

    public OrderedPair(E _1, F _2) {
        this._1 = _1;
        this._2 = _2;
    }
}
