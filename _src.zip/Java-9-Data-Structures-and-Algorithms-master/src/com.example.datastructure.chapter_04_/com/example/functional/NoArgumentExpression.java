package com.example.functional;

/**
 * Created by debasishc on 22/1/17.
 */
@FunctionalInterface
public interface NoArgumentExpression<E> {
    E value();
}
