package com.example.functional;

/**
 * Created by debasishc on 22/12/16.
 */
public interface TwoArgumentStatement<E,F> {
    void doSomething(E e, F f);
}
