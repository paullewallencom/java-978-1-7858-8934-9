module com.example.datastructure.chapter_10_{
	exports com.example.graph;

	requires com.example.datastructure.chapter_02_;
	requires com.example.datastructure.chapter_03_;
	requires com.example.datastructure.chapter_04_;
	requires com.example.datastructure.chapter_07_;
	requires com.example.datastructure.chapter_08_;
	requires com.example.datastructure.chapter_09_;
}
